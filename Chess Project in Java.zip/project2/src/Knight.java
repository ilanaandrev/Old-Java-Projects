// Written By: Ilana Andrev (ANDR1004) and Elsa Weiss (WEISS625)
// Knight.Java class
public class Knight {
    public int row;
    public int col;
    public boolean isBlack;

    public Knight(int row, int col, boolean isBlack) {
        this.row = row;
        this.col = col;
        this.isBlack = isBlack;
    }

    public boolean isMoveLegal(Board board, int endRow, int endCol) {

        //Case 1: left or right movement 1, up or down 2 squares
        if (Math.abs(this.col - endCol) == 1 && Math.abs(this.row - endRow) == 2) {
            return true;
        }

        //Case 2: Move left or rigt 2 squares and up or down 1 square
        if (Math.abs(this.col - endCol) == 2 && Math.abs(this.row - endRow) == 1) {
            return true;
        }

        //Case 3: Illegal
        else {
            return false;
        }
    }
}