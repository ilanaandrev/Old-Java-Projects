// Written By: Ilana Andrev (ANDR1004) and Elsa Weiss (WEISS625)
// King.Java class
public class King {
    public int row;
    public int col;
    public boolean isBlack;

    public King(int row, int col, boolean isBlack) {
        this.row = row;
        this.col = col;
        this.isBlack = isBlack;
    }

    //    White moves up
    //    Black moves down
    public boolean isMoveLegal(Board board, int endRow, int endCol) {
        if (board.verifyVertical(this.row, this.col, endRow, endCol)) { //checks moving forward or back
            if (((endRow - row) == 1 || (endRow - row) == -1)) { //checking only moving vertically one square
                return true;
            }
        } else if (board.verifyHorizontal(this.row, this.col, endRow, endCol)) { //checks left and right movements
            if (((endCol - col) == 1 || (endCol - col) == -1)) { //checking only moving horiz one square
                return true;
            }
        } else if (board.verifyDiagonal(this.row, this.col, endRow, endCol)) { //checks for diagonal movements
            if (((endRow - row) == 1 || (endRow - row) == -1) && (endCol - col == 1) || (endCol - col == -1)) { //checking only moving diag by one square
                return true;
            }
        }
        return false;
    }}


