// Written By: Ilana Andrev (ANDR1004) and Elsa Weiss (WEISS625)
//Game.Java class

import java.util.Scanner;


public class Game {
    //white pieces move upward
    //black pieces move downward
    public static void main(String[] args) {
        //creating and filling board
        Board board = new Board();


        Boolean isBlack =  false; //white always starts
        System.out.println("Board:");
        System.out.println(board); //printing board using our toString board method
        while(!board.isGameOver()) { //implied false

            //getting the color of who's turn it is to play
            String color;
            if(isBlack){ //==true is implied
                color = "black";
            }
            else{
                color = "white";
            }
            System.out.println("It is currently " + color + "'s turn to play.");
            System.out.println("What is your move? (format: [start row] [star col] [end row] [end col])");
            Scanner scanner = new Scanner(System.in);
            String line = scanner.nextLine(); //
            String splitline[] = line.split(" ", 4);
            int startRow = Integer.valueOf(splitline[0]);
            int startCol = Integer.valueOf(splitline[1]);
            int endRow = Integer.valueOf(splitline[2]);
            int endCol = Integer.valueOf(splitline[3]);
            boolean isMoveLegal = board.verifySourceAndDestination(startRow, startCol, endRow, endCol, isBlack);

            if(isMoveLegal == true){ //general if you can move piece
                if (board.movePiece(startRow, startCol, endRow, endCol)) { //if you can move the specific piece (ex: can i move queen that way)
                    System.out.println("Move Successful");
                    System.out.println(board);
                    isBlack = !isBlack;
                }
                else {
                    System.out.println("Move not legal, try again");
                }

            }
            else {
                System.out.println("Move not legal, try again");
            }
        }

        //when the game is over
        String color = "Black";
        if (board.isGameOver() == true) { //from here we know one king is missing and the winner's king is present
            //finding the winner king left on board
            for(int row = 0; row>8; row++){
                for (int col=0; col>8; col++){
                    Piece current = board.getPiece(row, col);
                    if (current.equals('\u2654')) { //white king is left in the game meaning white has won
                        color = "White";
                    }
                    }
                }
            }
        System.out.println(color + "has won the game!");
        }
    }
