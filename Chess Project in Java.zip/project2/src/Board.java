// Written By: Ilana Andrev (ANDR1004) and Elsa Weiss (WEISS625)
//Board.Java class
public class Board {

    // Instance variables
    private Piece[][] board; //piece on board is object in array
    //Board is array of type piece

    public Board() {
        board = new Piece[8][8];
        char[] blackPieces = {'\u265c', '\u265e', '\u265d', '\u265a', '\u265b', '\u265d', '\u265e', '\u265c'};
        char[] whitePieces = {'\u2656', '\u2658', '\u2657', '\u2655', '\u2654', '\u2657', '\u2658', '\u2656'};

        for (int i = 0; i < blackPieces.length; i++) {
            board[0][i] = new Piece(blackPieces[i], 0, i, true); //creates all the non-pawn black pieces
        }
        for (int i = 0; i < blackPieces.length; i++) {
            board[1][i] = new Piece('\u265f', 1, i, true); //creates all the black pawns
        }

        for (int j = 0; j < whitePieces.length; j++) {
            board[7][j] = new Piece(whitePieces[j], 7, j, false); //creates all the non-pawn white pieces
        }
        for (int j = 0; j < whitePieces.length; j++) {
            board[6][j] = new Piece('\u2659', 6, j, false); //creates all the white pawns

        }
    }


    // Accessor Methods
    public Piece getPiece(int row, int col) {
        Piece current = board[row][col];
        return current;
    }

    // Update a single cell of the board to the new piece.
    public void setPiece(int row, int col, Piece piece) {
        board[row][col] = piece;
    }

    // Game functionality methods
    public boolean movePiece(int startRow, int startCol, int endRow, int endCol) {
        boolean validMove = getPiece(startRow, startCol).isMoveLegal(this, endRow, endCol);
        if (validMove) { //implies true
            getPiece(startRow, startCol).setPosition(endRow, endCol); //sets the new piece coordinates
            setPiece(endRow, endCol, getPiece(startRow, startCol)); //get the piece and moves to end row and end col
            setPiece(startRow, startCol, null);
            return true;
        }
        return false;
    }


    // Determines whether the game has been ended, i.e., if one player's King
    // has been captured.
    public boolean isGameOver() {
        int kings = 0;
        for (int i = 0; i <= 7; i++) {
            for (int j = 0; j <= 7; j++) {
                Piece current = getPiece(i, j);
                if (current != null) { //making sure current is not null
                    char currentChar = current.toString().charAt(0); //getting character at index 0
                    if (currentChar == '\u2654' || currentChar == '\u265a') { //checking for unicode king vals
                        kings++;
                    }
                }

            }
        }
        if (kings == 2) {
            return false; //ask
        }
        return true; //ask
    }

    public String toString() {
        StringBuilder out = new StringBuilder();
        out.append(String.valueOf('\u2001')); //space at the beginning of the board for 0

        for (int i = 0; i < 8; i++) {
            out.append(String.valueOf('\u2003')); //smaller space in between characters
            out.append(i);
        }
        out.append('\n');
        for (int i = 0; i < board.length; i++) {
            out.append(i);
            out.append("|");
            for (int j = 0; j < board[0].length; j++) {
                out.append(board[i][j] == null ? String.valueOf('\u2003') + "|" : board[i][j] + "|");
            }
            out.append("\n");
        }
        return out.toString();
    }

    // Sets every cell of the array to null. For debugging and grading purposes.
    public void clear() {
        for (int i = 0; i <= 7; i++) {
            for (int j = 0; j <= 7; j++) {
                board[i][j] = null;
            }
        }
    }

    // Movement helper functions
    public boolean verifySourceAndDestination(int startRow, int startCol, int endRow, int endCol, boolean isBlack) {
        if (startRow < 0 || startRow > 7 || startCol < 0 || startCol > 7) { //start needs to be within bounds
            return false;
        }

        if (endRow < 0 || endRow > 7 || endCol < 0 || endCol > 7) { //end needs to be within bounds
            return false;
        }

        if (this.getPiece(startRow, startCol) == null) { //starting piece cannot be null in the box
            return false;
        }

        if (this.getPiece(startRow, startCol).getIsBlack() != isBlack) { //the piece we are moving is ours
            return false;
        }

        if (this.getPiece(endRow, endCol) != null) { //it is ok to end up in an empty spot
            if (this.getPiece(endRow, endCol).getIsBlack() == isBlack) { //if we land on spot with same color
                return false; //return false. you cant kill yourself
            }
        }
        return true;
    }


    // Check whether the 'start' position and 'end' position are adjacent to each other
    public boolean verifyAdjacent(int startRow, int startCol, int endRow, int endCol) {

        //checking bottom row three options
        if (startRow == endRow + 1) {
            if (startCol == endCol + 1) {
                return true;
            } else if (startCol == endCol - 1) {
                return true;
            } else if (startCol == endCol) {
                return true;
            }
        }

        //checking the bottom row three options
        if (startRow == endRow - 1) {
            if (startCol == endCol + 1) {
                return true;
            } else if (startCol == endCol - 1) {
                return true;
            } else if (startCol == endCol) {
                return true;
            }
        }

        //checking the left three options
        if (startCol == endCol + 1) {
            if (startRow == endRow + 1) {
                return true;
            } else if (startRow == endRow - 1) {
                return true;
            } else if (startRow == endRow) {
                return true;
            }
        }

        //checking the right three options
        if (startCol == endCol + 1) {
            if (startRow == endRow + 1) {
                return true;
            } else if (startRow == endRow - 1) {
                return true;
            } else if (startRow == endRow) {
                return true;
            }
        }

        //adjacent with same col
        if (startCol == endCol) {
            if (startRow == endRow) {
                return true;
            }
            if (startRow == endRow + 1) {
                return true;
            }
            if (startRow == endRow - 1) {
                return true;
            }
        }

        //adjacent with the same row
        if (startRow == endRow) {
            if (startCol == endCol) {
                return true;
            }
            if (startCol == endCol + 1) {
                return true;
            }
            if (startCol == endCol - 1) {
                return true;
            }
        }
        return false; //otherwise return false
    }

    public boolean verifyHorizontal(int startRow, int startCol, int endRow, int endCol) {

        //checking if start and end not in same row(horizontal)
        if (startRow != endRow) {
            return false;
        }
        //moving to the right
        if (startCol < endCol) {
            for (int i = 1; i < (endCol - startCol); i++) {
                if (board[startRow][startCol + i] != null) {
                    return false;
                }
            }
        }
        //moving to the left
        if (startCol > endCol) {
            for (int i = 1; i < (startCol - endCol); i++) {
                if (board[startRow][startCol - i] != null) {
                    return false;
                }
            }
        }
        return true;
    }

    public boolean verifyVertical(int startRow, int startCol, int endRow, int endCol) {
        //checking if start and end not in same column(vertical)
        if (startCol != endCol) {
            return false;
        }

        if (startRow > endRow) {
            for (int i = startRow - 1; i > endRow; i--) {
                if (board[i][startCol] != null) {
                    return false;
                }
            }
        }
        if (startRow < endRow) {
            for (int i = startRow + 1; i < endRow; i++) {
                if (board[i][startCol] != null) {
                    return false;
                }
            }
        }

        return true;
    }


    public boolean verifyDiagonal(int startRow, int startCol, int endRow, int endCol) {
        if ((startRow + startCol) != (endRow + endCol) && (startRow - startCol) != (endRow-endCol)) {
            return false;
        }

        //checking if direction is down and right (orange sketch)
        if (startCol < endCol) {
            if (startRow < endRow) {
                int tempRow = startRow + 1;
                int tempCol = startCol + 1;
                for (int i = startRow+1; i < endRow; i++){
                    if (board[tempRow][tempCol] != null) { //checking each space between start and end
                        return false;
                    }
                    tempRow++;
                    tempCol++;
                }
                return true;
            }
        }

        //checking if direction is up and right (blue sketch)
        if (startCol < endCol) {
            if (startRow > endRow) {
                int tempRow = startRow - 1;
                int tempCol = startCol + 1;
                for (int i = endRow+1; i < startRow; i++){
                    if (board[tempRow][tempCol] != null) { //checking each space between start and end
                        return false;
                    }
                    tempRow--;
                    tempCol++;
                }
                return true;
            }
        }


        //checking if direction is down and left (purple sketch)
        if (startCol > endCol) {
            if (startRow < endRow) {
                int tempRow = startRow + 1;
                int tempCol = startCol - 1;
                for (int i = startRow+1; i < endRow; i++){
                    if (board[tempRow][tempCol] != null) { //checking each space between start and end
                        return false;
                    }
                    tempRow++;
                    tempCol--;
                    }
                return true;
                }
            }

        //checking if direction is down and right (green sketch)
        if (startCol > endCol) {
            if (startRow > endRow) {
                int tempRow = startRow - 1;
                int tempCol = startCol - 1;
                for (int i = endRow+1; i < startRow; i++){
                    if (board[tempRow][tempCol] != null) { //checking each space between start and end
                        return false;
                    }
                    tempRow--;
                    tempCol--;
                }
                return true;
                }
            }

        //special case not moving anywhere as per the test requirements
        if (startCol == endCol) {
            if (startRow == endRow) {
                    return true;
                }
            }
        return false;
    }
}
//public class Board
