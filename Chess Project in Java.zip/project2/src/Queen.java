// Written By: Ilana Andrev (ANDR1004) and Elsa Weiss (WEISS625)
// Queen.Java class
public class Queen {
    public int row;
    public int col;
    public boolean isBlack;
    public Queen(int row, int col, boolean isBlack) {
        this.row = row;
        this.col = col;
        this.isBlack = isBlack;
    }

    //    White moves up
    //    Black moves down
    public boolean isMoveLegal(Board board, int endRow, int endCol) {
        if (board.verifyVertical(this.row, this.col, endRow, endCol)) { //checks moving forward or back
            return true;
        }
        else if(board.verifyHorizontal(this.row,this.col,endRow,endCol)) { //checks left and right movements
            return true;
        }
        else if (board.verifyDiagonal(this.row, this.col, endRow, endCol)) { //checks for diagonal movements
            return true;
        }
        else {
            return false;
        }
    }
}

