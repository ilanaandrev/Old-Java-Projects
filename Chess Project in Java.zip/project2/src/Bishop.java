// Written By: Ilana Andrev (ANDR1004) and Elsa Weiss (WEISS625)
// Bishop.Java class

public class Bishop {
    public int row;
    public int col;
    public boolean isBlack;
    public Bishop(int row, int col, boolean isBlack) {
        this.row = row;
        this.col = col;
        this.isBlack = isBlack;
    }

    //    White moves up
    //    Black moves down
    public boolean isMoveLegal(Board board, int endRow, int endCol) {

        // Case 1: Moving diagonally
        if(board.verifyDiagonal(this.row, this.col, endRow, endCol)) {
            return true;
        }

        //the bishop cannot move horiz/vertical and this checks for that
        else{
            return false;
        }
    }
}
