// Rectangle Class- This file creates a shape object of a rectangle
// Written By: Ilana Andrev (ANDR1004) and Elsa Weiss (WEISS625)

import java.awt.Color;

public class Rectangle {
    private double x_pos; //x position of upper left corner
    private double y_pos; //y position of upper left corner
    public double width;
    public double height;
    public Color rectangleColor;

    public Rectangle (double x, double y, double width, double height) {
        this.x_pos = x;
        this.y_pos = y;
        this.width = width;
        this.height = height;
    }
    public double calculatePerimeter() {
        return (this.width * 2) + (this.height * 2);
    }
    public double calculateArea() {
        return this.width * this.height;
    }
    public void setColor(Color rectColorParameter){
        this.rectangleColor = rectColorParameter;
    }
    public void setPos(double x, double y) {
        this.x_pos = x;
        this.y_pos = y;
    }
    public void setHeight(double height){
        this.height = height;
    }
    public void setWidth(double width){
        this.width = width;
    }
    public Color getColor() {
        return this.rectangleColor;
    }
    public double getXPos() {
        return this.x_pos;
    }
    public double getYPos() {
        return this.y_pos;
    }
    public double getHeight() {
        return this.height;
    }
    public double getWidth() {
        return this.width;
    }
}
