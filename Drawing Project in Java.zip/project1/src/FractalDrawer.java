// FractalDrawer Class- This file is our main method which calls all the other files/classes to draw the fractal drawing.
// Written By: Ilana Andrev (ANDR1004) and Elsa Weiss (WEISS625)

import java.awt.Color;
import java.util.Scanner;

public class FractalDrawer {
    private double totalArea=0;  // member variable for tracking the total area
    public FractalDrawer() {}  // constructor

    public Color[] colors= {Color.BLUE, Color.PINK, Color.GREEN, Color.CYAN};
    //creates an array to loop through colors
    // drawFractal creates a new Canvas object
    // and determines which shapes to draw a fractal by calling appropriate helper function
    // drawFractal returns the area of the fractal
    public double drawFractal(String type) {
        String shapeInput = type;
        int level = 7; //initial level is 7 and we go down
        Canvas can = new Canvas(800,800); //creates the new canvas for the drawing

        // for user input triangle
        if (shapeInput.equals("triangle")) {
            // calls drawTriangleFractal
            drawTriangleFractal(100, 100, 400, 400, Color.MAGENTA, can, level);
        }

        //for user input circle
        else if(shapeInput.equals("circle")) {
            //calls drawCircleFractal
            drawCircleFractal(100,400, 400, Color.MAGENTA, can, level);
        }

        //for user input rectangle
        else if (shapeInput.equals("rectangle")) {
            // calls drawRectangleFractal
            drawRectangleFractal(200, 100, 200, 100, Color.MAGENTA, can, level);
        }
        else {
            System.out.println("Try re-running the program again. You typed something wrong. "); //in case they type a wrong shape.
        }
    return totalArea;
    }


    // drawTriangleFractal draws a triangle fractal using recursive techniques
    public void drawTriangleFractal(double width, double height, double x, double y, Color c, Canvas can, int level) {
        //draw triangle by calling the Triangle class
        Triangle drawnTriangle = new Triangle (x, y, width, height);
        drawnTriangle.setColor(c); //sets color
        can.drawShape(drawnTriangle); //draw the triangle on the canvas
        totalArea += drawnTriangle.calculateArea(); //calculates the total area of every triangle drawn

        if (level ==0) {
        // stop drawing triangles. BASE CASE. we do not need to return anything.
        }
        else {
            double newWidth = width/2;
            double newHeight = height/2;
            Color newcolor = colors [level%4] ; //modulo keeps you looping in the colors array
            drawTriangleFractal(newWidth, newHeight, (x-(newWidth/2)), (y+newHeight), newcolor, can, level - 1); //left side triangle
            drawTriangleFractal(newWidth, newHeight,(x+width-(newWidth/2)), (y+newHeight), newcolor, can, level - 1); //right side triangle
            drawTriangleFractal(newWidth, newHeight,(x+(width/2)-(newWidth/2)),(y-height), newcolor, can, level - 1); // top side triangle
        }
    }


    // drawCircleFractal draws a circle fractal using recursive techniques
    public void drawCircleFractal(double radius, double x, double y, Color c, Canvas can, int level) {
        //draw circle by calling the Circle class
        Circle drawnCircle = new Circle(x, y, radius);
        drawnCircle.setColor(c); //sets color
        can.drawShape(drawnCircle); //draw the circle on the canvas
        totalArea += drawnCircle.calculateArea(); //calculates the totalArea of every circle drawn


        if (level == 0) {
        // stop drawing circles. BASE CASE. we do not need to return anything.
        }
        else {
            double newRadius = radius/2; //makes the radius smaller
            Color newcolor = colors [level%4] ; //modulo keeps you looping in the colors array
            drawCircleFractal(newRadius, x, (y+(radius+newRadius)), newcolor, can, level - 1); //bottom circle
            drawCircleFractal(newRadius, x, (y-(radius+newRadius)), newcolor, can, level - 1); //top circle
            drawCircleFractal(newRadius, (x+(radius+newRadius)), y, newcolor, can, level - 1); //right circle
            drawCircleFractal(newRadius, (x-(radius+newRadius)), y, newcolor, can, level - 1); //left circle
        }

    }

    // drawRectangleFractal draws a rectangle fractal using recursive techniques
    public void drawRectangleFractal(double width, double height, double x, double y, Color c, Canvas can, int level) {
        //draw rectangle by calling the Rectangle class
        Rectangle drawnRectangle = new Rectangle (x, y, width, height);
        drawnRectangle.setColor(c); //sets color
        can.drawShape(drawnRectangle); //draw the rectangle on the canvas
        this.totalArea += drawnRectangle.calculateArea(); //calculates the total area of every rectangle drawn

        if (level ==0) {
            // stop drawing rectangles. BASE CASE. we do not need to return anything.
            return; //returns void
        }
        else {
            double newWidth = width/2;
            double newHeight = height/2;
            Color newcolor = colors [level%4] ; //modulo keeps you looping in the colors array
            drawRectangleFractal(newWidth, newHeight, (x-newWidth), (y+height), newcolor, can, level - 1); //bottom
            drawRectangleFractal(newWidth, newHeight,(x+width), (y+height), newcolor, can, level - 1); //bottom
            drawRectangleFractal(newWidth, newHeight,(x-newWidth), (y-newHeight), newcolor, can, level - 1); //top
            drawRectangleFractal(newWidth, newHeight,(x+width), (y-newHeight), newcolor, can, level - 1); //top
        }
    }

    // main should ask user for shape input, and then draw the corresponding fractal.
    // should print area of fractal
    public static void main(String[] args){
        //getting user input
        System.out.println("Please type circle, triangle, or rectangle: ");
        Scanner myScanner = new Scanner(System.in);
        String shapeInput = myScanner.nextLine();
        FractalDrawer creation = new FractalDrawer(); // creating an instance of the fractal drawer
        double calculatedArea = creation.drawFractal(shapeInput);
        System.out.println(calculatedArea); //printing the total area
    }
}
