// Circle Class - This file creates a shape object of a circle
// Written By: Ilana Andrev (ANDR1004) and Elsa Weiss (WEISS625)

import java.awt.Color;
public class Circle {
    private double x_pos; //x position of center
    private double y_pos; //y position of center
    private double radius;
    private Color circleColor;

    public Circle(double x, double y, double r){
        //here is our constructor method
        this.x_pos = x;
        this.y_pos = y;
        this.radius = r;
    }
    public double calculatePerimeter() {
        return (2* Math.PI * this.radius);

    }

    public double calculateArea() {
        return (Math.PI * this.radius * this.radius);
    }

    public void setColor(Color colorParameter) { //ASK
        this.circleColor = colorParameter;
    }

    public void setPos(double x, double y) {
        this.x_pos = x;
        this.y_pos = y;
    }
    public void setRadius(double r){
        this.radius = r;
    }

    public Color getColor() {
        return this.circleColor;
    }
    public double getXPos() {
        return this.x_pos;
    }
    public double getYPos () {
        return this.y_pos;
    }
    public double getRadius() {
        return this.radius;
    }
}