// Triangle Class- This file creates a shape object of a triangle
// Written By: Ilana Andrev (ANDR1004) and Elsa Weiss (WEISS625)

import java.awt.Color;
public class Triangle {
    private double x_pos; //bottom left corner
    private double y_pos; //bottom left corner
    public double width;
    public double height;
    public Color triangleColor;
    public Triangle (double x, double y, double width, double height) {
        this.x_pos = x; //x position of bottom left corner
        this.y_pos = y; //y position of bottom left corner
        this.width = width;
        this.height = height;
    }
    public double calculatePerimeter() {
       //we have the width (short side) but we need the two equal long sides (isosceles)
        double longSide = Math.sqrt(( ((this.width/2)*(this.width/2)) + ((this.height)*(this.height)) ));
        double perimeter = this.width + longSide + longSide;
        return perimeter;
    }
    public double calculateArea() {
        return ((width * height) / 2);
    }
    public void setColor(Color triColorParameter){
        this.triangleColor = triColorParameter;
    }
    public void setPos(double x, double y) {
        this.x_pos = x;
        this.y_pos = y;
    }
    public void setHeight(double height){
        this.height = height;
    }
    public void setWidth(double width){
        this.width = width;
    }
    public Color getColor() {
        return this.triangleColor;
    }
    public double getXPos() {
        return this.x_pos;
    }
    public double getYPos() {
        return this.y_pos;
    }
    public double getHeight() {
        return this.height;
    }
    public double getWidth() {
        return this.width;
    }
}
